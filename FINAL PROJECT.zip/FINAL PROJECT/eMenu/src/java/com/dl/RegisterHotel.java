package com.dl;
import com.dl.DAL;
import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import java.sql.*;
public class RegisterHotel extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private static final String DATA_DIRECTORY = "hotel_img\\";
    private static final int MAX_MEMORY_SIZE = 1024 * 1024 * 2;
    private static final int MAX_REQUEST_SIZE = 1024 * 1024;
    String hotel_image;
    String hotel_name;
    String hotel_address;
    String hotel_desc;
    String hotel_location;
    String hotel_contact;
    int cat_code;
    String hotel_rating;
    String hotel_email;
    String hotel_password;
     
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
         // Check that we have a file upload request
        
        boolean isMultipart = ServletFileUpload.isMultipartContent(request);
        
        if (!isMultipart) {
            return;
        }
        
        DiskFileItemFactory factory = new DiskFileItemFactory();

        factory.setSizeThreshold(MAX_MEMORY_SIZE);

        factory.setRepository(new File(System.getProperty("java.io.tmpdir")));

        //String uploadFolder = getServletContext().getRealPath("")+ File.separator + DATA_DIRECTORY;
        
        String applicationPath = request.getServletContext().getRealPath("");
        String uploadFolder=applicationPath.substring(0,applicationPath.indexOf("\\build")) +File.separator +"web"+File.separator +DATA_DIRECTORY;

        ServletFileUpload upload = new ServletFileUpload(factory);

        upload.setSizeMax(MAX_REQUEST_SIZE);

        try {
            // Parse the request
            List items = upload.parseRequest(request);
            Iterator iter = items.iterator();
            while (iter.hasNext()) 
            {
                FileItem item = (FileItem) iter.next();
                if (!item.isFormField()) {
                    String fileName = new File(item.getName()).getName();
                    int d = fileName.lastIndexOf(".");
                    String ext=fileName.substring(d, fileName.length());
                    String oext=fileName.substring(d+1,fileName.length());
                    UUID idOne = UUID.randomUUID();
                    String filePath = uploadFolder + File.separator + idOne +"."+oext;
                    File uploadedFile = new File(filePath);
                    //System.out.println("OPERATION TYPE:"+operationType); 
                     System.out.println(filePath);
                    // saves the file to upload directory
                    item.write(uploadedFile);
                    String inputName=(String)item.getFieldName();
                    if(inputName.equalsIgnoreCase("hotel_image"))
                    {
                        hotel_image=idOne+"."+oext;
                        System.out.println(hotel_image);
                    } 
                   
                }
               
                if(item.isFormField())
                { 
                    String inputName = (String)item.getFieldName(); 
                    
                    if(inputName.equalsIgnoreCase("hotel_name")){ 
                    hotel_name = (String)item.getString();                     
                    }
                    if(inputName.equalsIgnoreCase("hotel_address")){ 
                    hotel_address = (String)item.getString();                     
                    }
                    if(inputName.equalsIgnoreCase("hotel_desc")){ 
                    hotel_desc = (String)item.getString();                        
                    }                     
                    if(inputName.equalsIgnoreCase("hotel_location")){ 
                    hotel_location  = (String)item.getString();                     
                    }                    
                    if(inputName.equalsIgnoreCase("hotel_contact")){ 
                    hotel_contact = (String)item.getString();                     
                    }
                    if(inputName.equalsIgnoreCase("cat_code")){ 
                    cat_code  = Integer.parseInt((String)item.getString());                   
                    }                     
                    if(inputName.equalsIgnoreCase("hotel_rating")){ 
                    hotel_rating  = (String)item.getString();                     
                    }
                    if(inputName.equalsIgnoreCase("hotel_email")){ 
                    hotel_email = (String)item.getString();                     
                    } 
                    if(inputName.equalsIgnoreCase("hotel_password")){ 
                    hotel_password = (String)item.getString(); 
                    } 
                    
                }             
            }
            String active_status="i";
            
            DAL d=new DAL();
            String sql="insert into hotel_details(hotel_image,hotel_name,hotel_email,hotel_contact,hotel_address,hotel_location,cat_code,hotel_rating,hotel_desc,hotel_password,active_status)"
 + "values('"+hotel_image+"','"+hotel_name+"','"+hotel_email+"','"+hotel_contact+"','"+hotel_address+"','"+hotel_location+"',"+cat_code+",'"+hotel_rating+"','"+hotel_desc+"','"+hotel_password+"','"+active_status+"')";
            System.out.println(sql);
           
            d.executeDML(sql);
            response.sendRedirect("hotel/index.jsp");
            
           
        } catch (FileUploadException ex) {
            throw new ServletException(ex);
        } catch (Exception ex) {
            throw new ServletException(ex);
        }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
