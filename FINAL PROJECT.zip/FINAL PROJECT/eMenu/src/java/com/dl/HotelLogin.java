/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dl;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.*;
import javax.servlet.http.*;
import com.dl.DAL;
import java.sql.*;

public class HotelLogin extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
           DAL d=new DAL();
            String hotel_email=request.getParameter("hotel_email");
            String hotel_password=request.getParameter("hotel_password");
            String sql="select * from hotel_details where hotel_email='"+hotel_email+"' and hotel_password='"+hotel_password+"' and active_status='a' limit 1";
            //out.print(admin_name);
            try{
                ResultSet rs=d.executeQuery(sql);
                if(rs.next()){
                HttpSession session= request.getSession(true);
                session.setAttribute("hotel_name", rs.getString("hotel_name"));
                session.setAttribute("hotel_code", rs.getInt("hotel_code"));
                rs.close();
                response.sendRedirect("hotelhome.jsp"); 
                }
                else{
                    rs.close();
                   response.sendRedirect("index.jsp"); 
                }
                
            }catch(SQLException s){                
                System.out.println(s);
            } 
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
