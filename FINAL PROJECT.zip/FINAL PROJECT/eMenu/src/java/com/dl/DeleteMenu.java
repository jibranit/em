
package com.dl;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.*;
import javax.servlet.http.*;
import com.dl.DAL;
import java.io.File;
import java.sql.*;

public class DeleteMenu extends HttpServlet {
    private static final String DATA_DIRECTORY = "menu_img\\";
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
           String applicationPath = request.getServletContext().getRealPath("");
           String uploadFolder=applicationPath.substring(0,applicationPath.indexOf("\\build")) +File.separator +"web"+File.separator +DATA_DIRECTORY;
            File f = new File(uploadFolder + File.separator + request.getParameter("image_path") );
            f.delete();
            DAL d=new DAL();
            String sql="delete from menu_details where image_code="+Integer.parseInt(request.getParameter("image_code"));
            d.executeDML(sql);
            response.sendRedirect("allmenu.jsp");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
