-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 31, 2018 at 07:42 PM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `emenu`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_details`
--

DROP TABLE IF EXISTS `admin_details`;
CREATE TABLE IF NOT EXISTS `admin_details` (
  `admin_code` int(11) NOT NULL AUTO_INCREMENT,
  `admin_email` varchar(40) DEFAULT NULL,
  `admin_password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`admin_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_details`
--

INSERT INTO `admin_details` (`admin_code`, `admin_email`, `admin_password`) VALUES
(1, 'admin@gmail.com', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `daily_special`
--

DROP TABLE IF EXISTS `daily_special`;
CREATE TABLE IF NOT EXISTS `daily_special` (
  `dsp_code` int(11) NOT NULL AUTO_INCREMENT,
  `hotel_code` int(11) NOT NULL,
  `update_date` date NOT NULL,
  `dsp_desc` text,
  PRIMARY KEY (`dsp_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `daily_special`
--

INSERT INTO `daily_special` (`dsp_code`, `hotel_code`, `update_date`, `dsp_desc`) VALUES
(1, 2, '2018-03-13', 'Hydrabadi Biryani'),
(2, 2, '2018-03-14', 'Crab Curry'),
(3, 3, '2018-03-22', 'Chicken tikka');

-- --------------------------------------------------------

--
-- Table structure for table `hotel_category`
--

DROP TABLE IF EXISTS `hotel_category`;
CREATE TABLE IF NOT EXISTS `hotel_category` (
  `cat_code` int(11) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(100) NOT NULL,
  PRIMARY KEY (`cat_code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hotel_category`
--

INSERT INTO `hotel_category` (`cat_code`, `cat_name`) VALUES
(1, 'Veg Family'),
(2, 'Veg Non-Veg Family'),
(3, 'Bar and Restaurant'),
(4, 'Others');

-- --------------------------------------------------------

--
-- Table structure for table `hotel_details`
--

DROP TABLE IF EXISTS `hotel_details`;
CREATE TABLE IF NOT EXISTS `hotel_details` (
  `hotel_code` int(11) NOT NULL AUTO_INCREMENT,
  `hotel_name` varchar(100) DEFAULT NULL,
  `hotel_email` varchar(40) DEFAULT NULL,
  `hotel_address` varchar(500) DEFAULT NULL,
  `hotel_location` varchar(50) DEFAULT NULL,
  `hotel_contact` varchar(12) DEFAULT NULL,
  `cat_code` int(11) DEFAULT NULL,
  `hotel_image` varchar(60) NOT NULL,
  `hotel_rating` varchar(40) DEFAULT NULL,
  `hotel_desc` varchar(100) DEFAULT NULL,
  `hotel_password` varchar(20) NOT NULL,
  `active_status` char(1) NOT NULL,
  PRIMARY KEY (`hotel_code`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hotel_details`
--

INSERT INTO `hotel_details` (`hotel_code`, `hotel_name`, `hotel_email`, `hotel_address`, `hotel_location`, `hotel_contact`, `cat_code`, `hotel_image`, `hotel_rating`, `hotel_desc`, `hotel_password`, `active_status`) VALUES
(3, 'Shalimar', 'shalimar@gmail.com', 'Mohammad ali road', 'Bhindi bazar', '24045634', 2, 'ce6cbdd8-e1e4-4e73-806c-83305296ebb0.jpg', '2 Star', 'Good food!', 'shalimar', 'a'),
(4, 'zaffran', 'zaffran@gmail.com', 'Colaba', 'Lokmnya Tilak road', '24097568', 2, '9377c83a-9c95-4f99-b5d8-a87fbd4ea2c1.jpg', 'No Star', 'Love food!\r\n\r\n\r\n', 'zaffran', 'a');

-- --------------------------------------------------------

--
-- Table structure for table `menu_details`
--

DROP TABLE IF EXISTS `menu_details`;
CREATE TABLE IF NOT EXISTS `menu_details` (
  `image_code` int(8) NOT NULL AUTO_INCREMENT,
  `hotel_code` int(11) NOT NULL,
  `image_path` varchar(60) NOT NULL,
  PRIMARY KEY (`image_code`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu_details`
--

INSERT INTO `menu_details` (`image_code`, `hotel_code`, `image_path`) VALUES
(13, 2, '74731476-c60b-4510-8d3a-9b307024d71c.jpg'),
(16, 2, '11888146-a6d9-4c4c-86ef-e29c0af32427.jpg'),
(17, 3, 'f2781396-4d7d-4ded-b5ab-cea8987e57f1.jpg'),
(18, 4, '1008790c-3565-42f6-b872-add1fcf88de4.jpg'),
(19, 3, 'adabe61b-3871-428d-a076-1553291387b8.jpg');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
